# Firebase Admin Node.js SDK Reference

The Admin SDK lets you interact with Firebase from privileged environments.
You can install it via our [npm package](https://www.npmjs.com/package/firebase-admin).

To get started using the Firebase Admin Node.js SDK, see
[Add the Firebase Admin SDK to your server](https://firebase.google.com/docs/admin/setup).

For source code, see the [Firebase Admin Node.js SDK GitHub repo](https://github.com/firebase/firebase-admin-node).
